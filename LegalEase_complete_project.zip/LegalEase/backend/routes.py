from typing import List
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field, field_validator
from ai_core.gemini_generator import GeminiDocumentGenerator

router = APIRouter()
generator = GeminiDocumentGenerator()

class DocumentRequest(BaseModel):
    document_type: str = Field(..., min_length=2, max_length=120)
    parties: str = Field(..., min_length=2, max_length=5000)
    terms: List[str] = Field(default_factory=list, max_length=30)
    effective_date: str = Field(..., min_length=2, max_length=80)
    jurisdiction: str = Field(default="India", min_length=2, max_length=120)
    additional_instructions: str = Field(default="", max_length=5000)

    @field_validator("terms")
    @classmethod
    def clean_terms(cls, value):
        return [item.strip() for item in value if item and item.strip()]

class DocumentResponse(BaseModel):
    document_type: str
    content: str

@router.post("/generate", response_model=DocumentResponse)
def generate_document(request: DocumentRequest):
    try:
        content = generator.generate_document(
            document_type=request.document_type,
            parties=request.parties,
            terms=request.terms,
            effective_date=request.effective_date,
            jurisdiction=request.jurisdiction,
            additional_instructions=request.additional_instructions,
        )
        return DocumentResponse(document_type=request.document_type, content=content)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Document generation failed: {exc}") from exc
