from io import BytesIO
from pathlib import Path
from xml.sax.saxutils import escape

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Image
from reportlab.pdfbase.pdfmetrics import stringWidth

LOGO_PATH = Path(__file__).resolve().parent.parent / "assets" / "logo.png"

def format_txt(text: str) -> bytes:
    return text.strip().encode("utf-8")

def _is_heading(line: str) -> bool:
    stripped = line.strip()
    return bool(stripped) and len(stripped) <= 100 and (
        stripped.isupper() or stripped.endswith(":") or
        (stripped[0].isdigit() and "." in stripped[:5])
    )

def format_docx(text: str, doc_type: str) -> bytes:
    doc = Document()
    section = doc.sections[0]
    section.top_margin = Inches(.75)
    section.bottom_margin = Inches(.75)
    section.left_margin = Inches(.9)
    section.right_margin = Inches(.9)

    if LOGO_PATH.exists():
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.add_run().add_picture(str(LOGO_PATH), width=Inches(1.0))

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(doc_type.upper())
    r.bold = True
    r.font.name = "Times New Roman"
    r.font.size = Pt(16)

    for line in text.splitlines():
        p = doc.add_paragraph()
        if not line.strip():
            continue
        r = p.add_run(line.strip())
        r.bold = _is_heading(line)
        r.font.name = "Times New Roman"
        r.font.size = Pt(11)

    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    fr = footer.add_run("LegalEase — AI-generated draft. Review before signing.")
    fr.font.name = "Times New Roman"
    fr.font.size = Pt(8)

    output = BytesIO()
    doc.save(output)
    return output.getvalue()

def format_pdf(text: str, doc_type: str) -> bytes:
    output = BytesIO()
    doc = SimpleDocTemplate(
        output, pagesize=A4, rightMargin=18*mm, leftMargin=18*mm,
        topMargin=22*mm, bottomMargin=18*mm, title=doc_type
    )
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "LegalTitle", parent=styles["Title"], fontName="Helvetica-Bold",
        fontSize=15, leading=18, alignment=TA_CENTER, spaceAfter=12
    )
    heading_style = ParagraphStyle(
        "LegalHeading", parent=styles["Heading2"], fontName="Helvetica-Bold",
        fontSize=11, leading=14, spaceBefore=8, spaceAfter=5
    )
    body_style = ParagraphStyle(
        "LegalBody", parent=styles["BodyText"], fontName="Helvetica",
        fontSize=9.5, leading=13, spaceAfter=6
    )
    story = []
    if LOGO_PATH.exists():
        logo = Image(str(LOGO_PATH), width=25*mm, height=25*mm)
        logo.hAlign = "CENTER"
        story.extend([logo, Spacer(1, 3*mm)])
    story.append(Paragraph(escape(doc_type.upper()), title_style))
    for line in text.splitlines():
        line = line.strip()
        if not line:
            story.append(Spacer(1, 2*mm))
        elif _is_heading(line):
            story.append(Paragraph(escape(line), heading_style))
        elif line.startswith("- "):
            story.append(Paragraph("• " + escape(line[2:]), body_style))
        else:
            story.append(Paragraph(escape(line), body_style))

    def footer(canvas, doc_obj):
        canvas.saveState()
        canvas.setFont("Helvetica", 7)
        canvas.drawCentredString(A4[0]/2, 9*mm, "LegalEase — AI-generated draft. Review before signing.")
        canvas.drawRightString(A4[0]-18*mm, 9*mm, f"Page {doc_obj.page}")
        canvas.restoreState()

    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    return output.getvalue()

def format_html_preview(text: str) -> str:
    blocks = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        safe = escape(line)
        if _is_heading(line):
            blocks.append(f"<h3>{safe}</h3>")
        elif line.startswith("- "):
            blocks.append(f"<li>{escape(line[2:])}</li>")
        else:
            blocks.append(f"<p>{safe}</p>")
    return "\n".join(blocks)
