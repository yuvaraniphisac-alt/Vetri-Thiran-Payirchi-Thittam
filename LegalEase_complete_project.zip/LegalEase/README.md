# LegalEase — AI-Powered Legal Document Generator

LegalEase is a FastAPI + Streamlit application for drafting editable legal-document text with Google Gemini and exporting it as TXT, DOCX, and PDF.

**Important:** LegalEase is a drafting/education tool, not a substitute for a qualified lawyer. AI-generated text can be incomplete or unsuitable for a particular jurisdiction. Review every document with an appropriately qualified legal professional before signing or relying on it.

## Architecture
- `frontend/app.py` — Streamlit UI
- `backend/main.py` — FastAPI application
- `backend/routes.py` — API endpoints and validation
- `ai_core/gemini_generator.py` — Gemini integration
- `services/document_formatter.py` — TXT/DOCX/PDF generation
- `utils/text_utils.py` — sanitization and HTML preview helpers
- `tests/` — API and formatter tests

The supplied specification selected Gemini 1.5 Pro. That model/SDK choice is outdated now, so this implementation uses Google's current `google-genai` SDK and a configurable model, defaulting to `gemini-3.8-flash`. Change `GEMINI_MODEL` if you want another currently available model.

## Setup
Python 3.10+ is recommended.

Windows:
```powershell
cd LegalEase
py -3.11 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

Set in `.env`:
```env
GEMINI_API_KEY=your_key_here
GEMINI_MODEL=gemini-3.8-flash
DEMO_MODE=false
BACKEND_URL=http://127.0.0.1:8000
```

For a no-key end-to-end test, set `DEMO_MODE=true`.

## Run
Terminal 1:
```powershell
.venv\Scripts\Activate.ps1
uvicorn backend.main:app --reload --host 127.0.0.1 --port 8000
```

Terminal 2:
```powershell
.venv\Scripts\Activate.ps1
streamlit run frontend/app.py
```

Open the Streamlit URL, normally `http://localhost:8501`. FastAPI docs: `http://127.0.0.1:8000/docs`.

## Test
```powershell
pytest -q
```

## API
`POST /generate` accepts:
```json
{
  "document_type": "Non-Disclosure Agreement",
  "parties": "Jane Doe (Disclosing Party), TechNova Inc. (Receiving Party)",
  "terms": ["Confidential information must be protected", "Either party may terminate with 15 days notice"],
  "effective_date": "2026-09-24",
  "jurisdiction": "India",
  "additional_instructions": "Use clear professional language."
}
```

## Production checklist
Add authentication, rate limiting, HTTPS, secret management, audit/retention controls, jurisdiction-specific legal review, and privacy protections before public deployment.
