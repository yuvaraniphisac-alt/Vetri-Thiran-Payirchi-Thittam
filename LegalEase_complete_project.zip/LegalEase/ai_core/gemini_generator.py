import os
from typing import Iterable
from dotenv import load_dotenv

load_dotenv()

SYSTEM_INSTRUCTION = """
You are LegalEase, an AI legal-document drafting assistant.

Draft structured legal-document text only from facts supplied by the user.
Do not invent names, dates, amounts, addresses, statutes, court decisions, or jurisdiction-specific
legal requirements. Use [MISSING INFORMATION] for material facts that are absent.

Rules:
1. Use a professional title and numbered clauses.
2. Reflect supplied parties, effective date, jurisdiction, and terms.
3. Keep the document internally consistent.
4. Do not claim the document is legally valid, legally reviewed, or guaranteed enforceable.
5. Do not fabricate legal citations.
6. Include signature blocks where appropriate.
7. End with a short Review Notice stating that the draft should be reviewed by a qualified
   legal professional before signing or relying on it.
8. Return plain text only; no Markdown code fences.
"""

class GeminiDocumentGenerator:
    def __init__(self):
        self.model = os.getenv("GEMINI_MODEL", "gemini-3.8-flash")
        self.demo_mode = os.getenv("DEMO_MODE", "true").lower() in {"1", "true", "yes"}
        self.api_key = os.getenv("GEMINI_API_KEY", "").strip()
        self._client = None

    def _get_client(self):
        if self._client is None:
            if not self.api_key:
                raise ValueError("GEMINI_API_KEY is not configured. Set it in .env or enable DEMO_MODE=true.")
            from google import genai
            self._client = genai.Client(api_key=self.api_key)
        return self._client

    @staticmethod
    def _terms_text(terms: Iterable[str]) -> str:
        items = list(terms)
        return "\n".join(f"- {item}" for item in items) if items else "- [MISSING TERMS]"

    def _build_prompt(self, document_type, parties, terms, effective_date, jurisdiction, additional_instructions):
        return f"""
Create a draft {document_type} using only the information below.

DOCUMENT TYPE:
{document_type}

PARTIES:
{parties}

EFFECTIVE DATE:
{effective_date}

JURISDICTION:
{jurisdiction}

REQUESTED TERMS:
{self._terms_text(terms)}

ADDITIONAL INSTRUCTIONS:
{additional_instructions or "[NONE]"}

Structure:
TITLE
PARTIES / RECITALS (where appropriate)
NUMBERED CLAUSES
SIGNATURES
REVIEW NOTICE
"""

    def _demo_document(self, document_type, parties, terms, effective_date, jurisdiction, additional_instructions):
        clauses = "\n".join(f"{i}. {term}" for i, term in enumerate(terms or ["[MISSING TERMS]"], 1))
        return f"""{document_type.upper()}

Effective Date: {effective_date}
Jurisdiction: {jurisdiction}

PARTIES
{parties}

AGREEMENT

The parties identified above intend to enter into this {document_type} on the effective date stated above.

TERMS AND CONDITIONS

{clauses}

GENERAL PROVISIONS

1. Entire Agreement. The parties should confirm that this document represents their complete agreement.
2. Amendments. Any amendment should be made in writing and approved by the parties.
3. Notices. The parties should specify the required method and address for formal notices.
4. Severability. If a provision is determined to be unenforceable, obtain legal advice regarding the remaining provisions.
5. Governing Law. The governing-law provision should be confirmed for the stated jurisdiction.

SIGNATURES

Party 1: ______________________________
Name: ________________________________
Date: _________________________________

Party 2: ______________________________
Name: ________________________________
Date: _________________________________

REVIEW NOTICE
This is an AI-generated draft for editing and review. It is not legal advice and should be reviewed by a qualified legal professional before signing or relying on it.
"""

    def generate_document(self, document_type, parties, terms, effective_date, jurisdiction, additional_instructions=""):
        if self.demo_mode:
            return self._demo_document(document_type, parties, terms, effective_date, jurisdiction, additional_instructions)

        prompt = self._build_prompt(
            document_type, parties, terms, effective_date, jurisdiction, additional_instructions
        )
        client = self._get_client()
        response = client.models.generate_content(
            model=self.model,
            contents=prompt,
            config={
                "system_instruction": SYSTEM_INSTRUCTION,
                "temperature": 0.2,
                "max_output_tokens": 8192,
            },
        )
        text = getattr(response, "text", None)
        if not text or not text.strip():
            raise ValueError("Gemini returned an empty response.")
        return text.strip()
