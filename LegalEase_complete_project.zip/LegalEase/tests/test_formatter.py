from services.document_formatter import format_docx, format_pdf, format_txt

def test_txt_export():
    assert format_txt("Hello LegalEase")==b"Hello LegalEase"

def test_docx_export():
    assert format_docx("TITLE\n\nA sample clause.","Agreement")[:2]==b"PK"

def test_pdf_export():
    assert format_pdf("TITLE\n\nA sample clause.","Agreement").startswith(b"%PDF")
