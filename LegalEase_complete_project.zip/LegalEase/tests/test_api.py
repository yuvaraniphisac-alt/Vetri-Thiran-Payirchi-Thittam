from fastapi.testclient import TestClient
from backend.main import app
client = TestClient(app)

def test_health():
    r=client.get("/health")
    assert r.status_code==200
    assert r.json()["status"]=="ok"

def test_generate_demo_document():
    payload={
        "document_type":"Non-Disclosure Agreement",
        "parties":"Alice (Disclosing Party), Example Ltd (Receiving Party)",
        "terms":["Confidentiality","15 days notice for termination"],
        "effective_date":"2026-09-24",
        "jurisdiction":"India",
        "additional_instructions":"",
    }
    r=client.post("/generate",json=payload)
    assert r.status_code==200
    body=r.json()
    assert body["document_type"]=="Non-Disclosure Agreement"
    assert "Confidentiality" in body["content"]
