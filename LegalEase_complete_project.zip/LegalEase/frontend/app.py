import os
from datetime import date
import requests
import streamlit as st
from dotenv import load_dotenv
from services.document_formatter import format_docx, format_html_preview, format_pdf, format_txt
from utils.text_utils import sanitize_text

load_dotenv()
st.set_page_config(page_title="LegalEase", page_icon="⚖️", layout="wide")
BACKEND_URL = os.getenv("BACKEND_URL", "http://127.0.0.1:8000").rstrip("/")

def call_backend(payload):
    response = requests.post(f"{BACKEND_URL}/generate", json=payload, timeout=180)
    if response.status_code >= 400:
        try:
            detail = response.json().get("detail", response.text)
        except ValueError:
            detail = response.text
        raise RuntimeError(str(detail))
    return response.json()["content"]

st.markdown("""
<style>
.hero{padding:1.4rem 1.6rem;border-radius:16px;background:linear-gradient(135deg,#111827,#1f2937);color:white;margin-bottom:1.2rem}
.hero h1{margin:0}.hero p{margin:.4rem 0 0;color:#d1d5db}
.preview{padding:1.4rem;border-radius:12px;background:#111827;color:#f3f4f6;border:1px solid #374151;max-height:650px;overflow-y:auto}
.preview h3{color:#fbbf24}.notice{font-size:.85rem;color:#6b7280}
</style>
""", unsafe_allow_html=True)

st.markdown('<div class="hero"><h1>⚖️ LegalEase</h1><p>AI-assisted legal document drafting, editing and export.</p></div>', unsafe_allow_html=True)

left, right = st.columns([.9, 1.1], gap="large")
with left:
    st.subheader("Document details")
    document_type = st.selectbox("Document type", [
        "Employment Contract", "Non-Disclosure Agreement", "Lease Agreement",
        "Service Agreement", "Freelance Work Contract", "Employment Offer Letter",
        "General Agreement",
    ])
    parties = st.text_area("Parties involved", placeholder="Jane Doe (Service Provider), TechNova Inc. (Client)", height=100)
    effective_date = st.date_input("Effective date", value=date.today())
    jurisdiction = st.text_input("Jurisdiction", value="India")
    terms_raw = st.text_area(
        "Terms & conditions",
        placeholder="Payment to be made within 30 days of invoice;\nConfidentiality must be maintained;\nEither party may terminate with 15 days notice",
        height=180,
        help="Enter one term per line or separate terms with semicolons.",
    )
    additional_instructions = st.text_area("Additional instructions (optional)", height=100)
    generate = st.button("Generate Document", type="primary", use_container_width=True)

with right:
    st.subheader("Document preview")
    if generate:
        if not parties.strip():
            st.error("Please enter the parties involved.")
        else:
            terms = [x.strip() for x in terms_raw.replace(";", "\n").splitlines() if x.strip()]
            payload = {
                "document_type": document_type,
                "parties": parties.strip(),
                "terms": terms,
                "effective_date": effective_date.isoformat(),
                "jurisdiction": jurisdiction.strip() or "India",
                "additional_instructions": additional_instructions.strip(),
            }
            with st.spinner("Generating draft..."):
                try:
                    st.session_state["document"] = sanitize_text(call_backend(payload))
                    st.session_state["doc_type"] = document_type
                except Exception as exc:
                    st.error(f"Generation failed: {exc}")

    if "document" in st.session_state:
        current = st.text_area("Editable document", value=st.session_state["document"], height=520, key="editable_document")
        st.session_state["document"] = current
        st.markdown("**Styled preview**")
        st.markdown(f'<div class="preview">{format_html_preview(current)}</div>', unsafe_allow_html=True)
        st.markdown("### Download")
        b1,b2,b3=st.columns(3)
        safe_name=st.session_state.get("doc_type","legal_document").lower().replace(" ","_")
        with b1:
            st.download_button("Download TXT", format_txt(current), f"{safe_name}.txt", "text/plain", use_container_width=True)
        with b2:
            st.download_button("Download DOCX", format_docx(current, st.session_state.get("doc_type","Legal Document")), f"{safe_name}.docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", use_container_width=True)
        with b3:
            st.download_button("Download PDF", format_pdf(current, st.session_state.get("doc_type","Legal Document")), f"{safe_name}.pdf", "application/pdf", use_container_width=True)
    else:
        st.info("Enter the details and click Generate Document.")

st.divider()
st.markdown('<div class="notice">LegalEase provides AI-generated drafts for review. It is not a substitute for qualified legal advice.</div>', unsafe_allow_html=True)
