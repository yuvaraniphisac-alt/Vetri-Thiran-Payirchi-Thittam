Replace `assets/logo.png` with your own PNG logo for branding. A square transparent PNG works well.
